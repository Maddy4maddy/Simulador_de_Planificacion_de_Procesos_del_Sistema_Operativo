import tkinter as tk
from styles import EstilosHospital


class VentanaSimulacionPaso:

    def __init__(self, root, controller):

        self.controller = controller

        self.ventana = tk.Toplevel(root)
        self.ventana.title("Simulación Paso a Paso")
        self.ventana.geometry("900x500")
        self.ventana.configure(bg=EstilosHospital.COLORES["fondo"])

        self.label_estado = tk.Label(
            self.ventana,
            text="Listo",
            font=("Segoe UI", 14),
            bg=EstilosHospital.COLORES["fondo"]
        )
        self.label_estado.pack(pady=10)

        self.label_actual = tk.Label(
            self.ventana,
            text="Paciente actual: -",
            font=("Segoe UI", 12, "bold"),
            fg="red",
            bg=EstilosHospital.COLORES["fondo"]
        )
        self.label_actual.pack(pady=5)

        self.btn = tk.Button(
            self.ventana,
            text="Iniciar simulación",
            command=self.iniciar
        )
        self.btn.pack(pady=10)

        self.canvas = tk.Canvas(self.ventana, bg="white", height=300)
        self.canvas.pack(fill="both", expand=True)

    def iniciar(self):

        configuracion = {
            "Rojo": "FIFO",
            "Amarillo": "SJF",
            "Verde": "RR",
            "Cita": "FIFO",
            "Seguimiento": "RR",
            "Embarazada": "RR"
        }

        gen = self.controller.ejecutar_paso_a_paso(configuracion, quantum=2)

        self.animar(gen)

    def animar(self, gen):

        try:
            timeline, paciente, tiempo = next(gen)

            self.label_estado.config(text=f"Tiempo actual: {tiempo}")
            self.label_actual.config(text=f"Paciente: {paciente.nombre}")

            self.dibujar(timeline)

            self.ventana.after(800, lambda: self.animar(gen))

        except StopIteration:
            self.label_estado.config(text="Simulación terminada")

    def dibujar(self, timeline):

        self.canvas.delete("all")

        escala = 30
        y = 100

        for item in timeline:

            x1 = item["inicio"] * escala
            x2 = item["fin"] * escala

            self.canvas.create_rectangle(x1, y, x2, y + 40, fill="#8B0000")
            self.canvas.create_text((x1 + x2) / 2, y + 20, text=f"P{item['id']}", fill="white")