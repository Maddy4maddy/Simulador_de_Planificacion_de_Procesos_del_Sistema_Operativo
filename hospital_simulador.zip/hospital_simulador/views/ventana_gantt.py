import tkinter as tk
from tkinter import ttk
from styles import EstilosHospital


class VentanaGantt:

    def __init__(self, root, gantt_data):
        self.ventana = tk.Toplevel(root)
        self.ventana.title("Diagrama de Gantt - MLQ")
        self.ventana.geometry("1000x500")
        self.ventana.configure(bg=EstilosHospital.COLORES["fondo"])

        self.gantt_data = gantt_data

        self.crear_ui()

    def crear_ui(self):

        EstilosHospital.crear_header(self.ventana, "DIAGRAMA DE GANTT")

        frame = tk.Frame(self.ventana, bg=EstilosHospital.COLORES["fondo"])
        frame.pack(fill="both", expand=True, padx=10, pady=10)

        canvas = tk.Canvas(frame, bg="white", height=200)
        canvas.pack(fill="both", expand=True)

        self.dibujar_gantt(canvas)

    def dibujar_gantt(self, canvas):

        if not self.gantt_data:
            return

        escala = 20  # px por unidad de tiempo
        y = 80

        for item in self.gantt_data:
            pid, inicio, fin = item
            x1 = inicio * escala
            x2 = fin * escala

            canvas.create_rectangle(x1, y, x2, y + 60, fill="#E65100")
            canvas.create_text((x1 + x2) / 2, y + 30, text=f"P{pid}", fill="white")

            canvas.create_text(x1, y + 75, text=str(inicio))
            canvas.create_text(x2, y + 75, text=str(fin))