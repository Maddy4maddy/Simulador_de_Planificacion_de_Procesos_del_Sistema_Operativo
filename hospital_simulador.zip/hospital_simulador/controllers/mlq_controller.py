from controllers.fifo_controller import FIFOController
from controllers.sjf_controller import SJFController
from controllers.rr_controller import RoundRobinController


class MLQController:

    def __init__(self):
        self.fifo = FIFOController()
        self.sjf = SJFController()
        self.rr = RoundRobinController()

    def separar_colas(self, pacientes):

        colas = {
            "Rojo": [],
            "Amarillo": [],
            "Embarazada": [],
            "Verde": [],
            "Cita": [],
            "Seguimiento": []
        }

        for paciente in pacientes:
            colas[paciente.tipo].append(paciente)

        return colas

    def ejecutar(self, pacientes, configuracion, quantum=2):

        colas = self.separar_colas(pacientes)

        resultados = {}

        for tipo, lista_pacientes in colas.items():

            if not lista_pacientes:
                continue

            algoritmo = configuracion.get(tipo, "FIFO")

            if algoritmo == "FIFO":

                resultado = self.fifo.ejecutar(
                    lista_pacientes
                )

            elif algoritmo == "SJF":

                resultado = self.sjf.ejecutar(
                    lista_pacientes
                )

            elif algoritmo == "RR":

                resultado = self.rr.ejecutar(
                    lista_pacientes,
                    quantum
                )

            else:
                raise ValueError(
                    f"Algoritmo no válido para {tipo}"
                )

            resultados[tipo] = resultado

        return resultados